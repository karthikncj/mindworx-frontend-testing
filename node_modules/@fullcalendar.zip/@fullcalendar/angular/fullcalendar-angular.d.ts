/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';

//# sourceMappingURL=fullcalendar-angular.d.ts.map