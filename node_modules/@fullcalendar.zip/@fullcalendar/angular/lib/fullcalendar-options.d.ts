export declare const OPTION_IS_DEEP: {
    headerToolbar: boolean;
    footerToolbar: boolean;
    events: boolean;
    eventSources: boolean;
    resources: boolean;
};
