export declare function deepCopy(input: any): any;
export declare function shallowCopy(val: any): any;
export declare function mapHash(input: any, func: any): {};
